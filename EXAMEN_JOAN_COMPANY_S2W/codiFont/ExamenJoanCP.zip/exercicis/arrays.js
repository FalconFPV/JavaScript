import { getActors } from "../js/servidor.js";
//Exercici 1

const totalactors = JSON.parse(getActors());
const actors = totalactors.map(actor => new Actor(actor.actorId, actor.firstName, actor.lastName));
console.log(actors);

//Exercici 2

//Exercici 3


